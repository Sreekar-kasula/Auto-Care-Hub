function logout() {
    window.location.href = "Homelogin"; // Redirect to login page
  }
