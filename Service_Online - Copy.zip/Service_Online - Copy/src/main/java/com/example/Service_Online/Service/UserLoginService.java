package com.example.Service_Online.Service;

import com.example.Service_Online.Bean.UserLogin;
import com.example.Service_Online.repository.UserLoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserLoginService {

    @Autowired
    private UserLoginRepository userLoginRepository;

    public String login(String username, String password) {
        return userLoginRepository.findByUsername(username.toLowerCase())
            .map(user -> "Welcome back!")
            .orElseGet(() -> {
                UserLogin newUser = new UserLogin();
                newUser.setUsername(username);
                newUser.setPassword(password); 
                userLoginRepository.save(newUser);
                return "First-time login, user saved!";
            });
    }
}
