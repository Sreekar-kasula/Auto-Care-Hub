package com.example.Service_Online.Controller;

import com.example.Service_Online.Service.UserLoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    @Autowired
    private UserLoginService userLoginService;

    // It is for Homelogin
    @GetMapping("/Homelogin")
    public String showHomeloginPage() {
        return "Homelogin";
    }

    // For Login page
    @GetMapping("/Login")
    public String showLoginPage() {
        return "Login";
    }

    // Process Login form submission
    @PostMapping("/Login")
    public String login(@RequestParam String username, @RequestParam String password, Model model) {
        String loginMessage = userLoginService.login(username, password);
        model.addAttribute("message", loginMessage);
        return "Home"; // optionally redirect to Home page
    }

    // For Home page
    @GetMapping("/Home")
    public String showHomePage() {
        return "Home";
    }

    // For Service page
    @GetMapping("/Service")
    public String showServicePage() {
        return "Service";
    }

    // For Service-Expert page
    @GetMapping("/Service-Expert")
    public String showServiceExpert() {
        return "Service-Expert";
    }
}
