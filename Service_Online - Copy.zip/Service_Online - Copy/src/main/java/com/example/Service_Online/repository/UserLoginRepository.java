package com.example.Service_Online.repository;

import com.example.Service_Online.Bean.UserLogin;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLoginRepository extends JpaRepository<UserLogin, Long> {
	Optional<UserLogin> findByUsername(String email);
}
