package com.example.Service_Online.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.Service_Online.Bean.Booking;
import com.example.Service_Online.repository.BookingRepository;


@Service
public class BookingService {
	private final BookingRepository bookingRepo;
	
	@Autowired
	public BookingService(BookingRepository bookingRepo) {
		this.bookingRepo=bookingRepo;
	}
	
	public void saveBooking(Booking booking) {
		bookingRepo.save(booking);
		
	}
}
