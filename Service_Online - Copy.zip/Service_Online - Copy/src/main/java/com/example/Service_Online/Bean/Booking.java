package com.example.Service_Online.Bean;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Booking")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private long id;

    @Column(name = "Full_Name", nullable = false)
    private String fullName;

    @Column(name = "Contact_Number", nullable = false)
    private Long contactNumber;

    @Column(name = "Email", nullable = false)
    private String email;

    @Column(name = "Car_Type", nullable = false)
    private String carTypeStr = "";

    @Column(name = "Preferred_Date", nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date preferredDate;

    @Column(name = "Service", nullable = false)
    private String serviceStr = "";

    // Getters and setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Long getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(Long contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Store and retrieve car type as List<String>
    public List<String> getCarType() {
        if (carTypeStr == null || carTypeStr.isEmpty()) {
            return List.of();
        }
        return Arrays.asList(carTypeStr.split(","));
    }

    public void setCarType(List<String> carType) {
        this.carTypeStr = String.join(",", carType);
    }

    // Store and retrieve services as List<String>
    public List<String> getService() {
        if (serviceStr == null || serviceStr.isEmpty()) {
            return List.of();
        }
        return Arrays.asList(serviceStr.split(","));
    }

    public void setService(List<String> service) {
        this.serviceStr = String.join(",", service);
    }

    public Date getPreferredDate() {
        return preferredDate;
    }

    public void setPreferredDate(Date preferredDate) {
        this.preferredDate = preferredDate;
    }
}
