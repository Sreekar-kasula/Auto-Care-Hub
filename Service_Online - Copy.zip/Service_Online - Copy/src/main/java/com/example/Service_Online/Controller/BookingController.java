package com.example.Service_Online.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.Service_Online.Bean.Booking;
import com.example.Service_Online.Service.BookingService;

@Controller
public class BookingController {
    
    @Autowired
    private BookingService bookingService;
    
    @GetMapping("/Book-Now")
    public String showBookingForm(Model model) {
        model.addAttribute("bookingForm", new Booking());
        return "Book-Now";
    }

    @PostMapping("/submitBooking")
    public String saveBooking(@ModelAttribute("bookingForm") Booking booking) {
        bookingService.saveBooking(booking);
        return "redirect:/BookComplete"; 
    }

    @GetMapping("/BookComplete")
    public String showBookCompleteForm() {
        return "BookComplete"; 
    }

    
}
